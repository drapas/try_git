<?php

XTS\Admin\Modules\Options\Page::get_instance()->page_content();
