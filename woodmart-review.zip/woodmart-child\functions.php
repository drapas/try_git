<?php
/**
 * Enqueue script and styles for child theme
 */
function woodmart_child_enqueue_styles() {
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'woodmart-style' ), woodmart_get_theme_info( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'woodmart_child_enqueue_styles', 10010 );
/**
 * Remove product data tabs
 */
add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tabs', 98 );

function woo_remove_product_tabs( $tabs ) {

    unset( $tabs['reviews'] );    // Remove the reviews tab
 
    return $tabs;
}
// Збільшуємо кількість записів, які повертає REST API WooCommerce
add_filter( 'woocommerce_rest_products_per_page', function( $limit ) {
    return 50; // Встановлюємо ліміт у 50 записів
} );

// Збільшуємо кількість варіацій продуктів, які відправляються через REST API
add_filter( 'woocommerce_rest_product_variation_per_page', function( $limit ) {
    return 50; // Встановлюємо ліміт у 50 варіацій
} );

if ( SITECOOKIEPATH != COOKIEPATH ) {
    setcookie(TEST_COOKIE, 'WP Cookie check', 0, SITECOOKIEPATH, COOKIE_DOMAIN);
}